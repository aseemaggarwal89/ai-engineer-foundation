from app.application.ai.core.ai_reliability_pipeline import AIReliabilityPipeline
from app.application.ai.validator.request.ai_guardrails import AIGuardrails
from app.application.ai.services.summary_service import SummaryService
from app.application.ai.validator.request.ai_safety import AISafetyFilter
from app.application.ai.validator.response.hallucination_guard import HallucinationGuard
from app.application.ai.validator.response.response_scorer import AIResponseScorer
from app.application.ai.validator.response.response_validator import AIResponseValidator
from app.dependencies.deps import settings
from app.core.timeout import timeout
from app.domain.exceptions.exceptions import ResponseValidationError

cf = settings()


class SummarizeTextUseCase:

    def __init__(
        self,
        guardrails: AIGuardrails,
        reliability_pipeline: AIReliabilityPipeline,
        summary_service: SummaryService,
    ):
        self.guardrails = guardrails
        self.reliability_pipeline = reliability_pipeline
        self.summary_service = summary_service

    @timeout(cf.ai.timeout_seconds)
    async def execute(self, text: str) -> list[str]:

        # 🔥 Layer 7 protections
        self.guardrails.validate_prompt(text)
        self.safety.check(text)

        try:
            bullets = await self.summary_service.summarize(text)
    
        except Exception:
            if not self.fallback_service:
                raise

        # Zero-trust boundary
        validated, score = self.reliability_pipeline.run(response=bullets)
        if score < 0.6:
            raise ResponseValidationError("Low confidence AI output")

        return validated