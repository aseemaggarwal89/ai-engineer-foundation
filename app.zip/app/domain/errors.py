
class UserAlreadyExistsError(Exception):
    pass
