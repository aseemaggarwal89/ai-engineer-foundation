from fastapi import APIRouter
from app.security.jwt import create_access_token

router = APIRouter(prefix="/auth")


@router.post("/token")
async def login():
    # Assume user already authenticated (password check omitted for Step 1)
    token = create_access_token(subject="USER_ID_FROM_DB")
    return {"access_token": token}