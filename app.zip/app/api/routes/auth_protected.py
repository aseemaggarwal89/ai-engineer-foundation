# from fastapi import APIRouter, Depends

# from app.dependencies.use_cases import get_list_users_use_case
# from app.domain.entities.user import User
# from app.domain.entities.user_role import UserRole
# from app.domain.use_cases.user.get_current_user import GetCurrentUserUseCase
# from app.domain.use_cases.user.list_users import ListUsersUseCase
# from app.security.dependencies import (
#     get_current_active_user,
#     get_current_user,
# )
# from app.schemas.user import UserListResponse, UserResponse
# from app.security.authorization import require_role

